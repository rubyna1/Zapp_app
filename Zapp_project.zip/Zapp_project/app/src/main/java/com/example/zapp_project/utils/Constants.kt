package com.example.zapp_project.utils

object Constants {
    const val BASE_URL="https://graphqlzero.almansi.me/api"
}