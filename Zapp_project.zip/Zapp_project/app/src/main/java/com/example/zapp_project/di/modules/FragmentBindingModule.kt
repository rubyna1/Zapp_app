package com.example.zapp_project.di.modules

import com.example.zapp_project.di.scopes.FragmentScope
import com.example.zapp_project.ui.data.DataFragment
import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentBindingModule {
    @FragmentScope
    @ContributesAndroidInjector
    abstract fun bindDataFragment(): DataFragment
}