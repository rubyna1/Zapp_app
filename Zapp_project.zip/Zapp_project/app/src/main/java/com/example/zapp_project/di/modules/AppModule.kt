package com.example.zapp_project.di.modules

class AppModule {
}