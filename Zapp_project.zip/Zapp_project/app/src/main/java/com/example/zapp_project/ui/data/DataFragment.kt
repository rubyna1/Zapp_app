package com.example.zapp_project.ui.data

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.lifecycleScope
import com.apollographql.apollo3.ApolloClient
import com.apollographql.apollo3.network.okHttpClient
import com.example.zapp_project.FindAlbumQuery
import com.example.zapp_project.R
import dagger.android.support.DaggerFragment
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor

class DataFragment : DaggerFragment() {
    companion object {
        fun newInstance() = DataFragment()
    }

    lateinit var client: ApolloClient
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_data, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialize()
    }

    private fun initialize() {
        client = setUpApolloClient()
        Log.i("sieouwoewew", "response fata ${client}")
        lifecycleScope.launchWhenResumed {
            val response = client.query(FindAlbumQuery("5")).execute()
            Log.i("sieouwoewew", "response fata ${response.data}")
        }

    }

    fun setUpApolloClient(): ApolloClient {
        val logging = HttpLoggingInterceptor()
        logging.level = HttpLoggingInterceptor.Level.BODY
        val okHttp = OkHttpClient.Builder().addInterceptor(logging)
        return ApolloClient.builder().serverUrl("https://graphqlzero.almansi.me/api")
            .okHttpClient(okHttp.build()).build()

    }
}