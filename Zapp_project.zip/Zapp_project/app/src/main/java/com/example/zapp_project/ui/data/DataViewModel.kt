package com.example.zapp_project.ui.data

import com.apollographql.apollo3.ApolloClient
import javax.inject.Inject
import androidx.lifecycle.viewModelScope

class DataViewModel {
    @Inject
    lateinit var client: ApolloClient

    fun findAlbum(id:String){
        viewModelScope.launch{

        }
    }
}