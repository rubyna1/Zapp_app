package com.example.zapp_project.ui

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.apollographql.apollo3.ApolloClient
import com.example.zapp_project.CreateTodoMutation
import com.example.zapp_project.FindAlbumQuery
import com.example.zapp_project.R
import com.example.zapp_project.ui.data.DataFragment
import dagger.android.support.DaggerAppCompatActivity
import dagger.android.support.DaggerFragment

class MainContainerActivity : DaggerAppCompatActivity() {
    lateinit var client:ApolloClient
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_container)
        initialize()
    }

//    private fun initialize() {
//        showFragment(DataFragment.newInstance(), "DataFragment")
//    }
//
    private fun showFragment(fragment: DaggerFragment, tag: String) {
        supportFragmentManager.beginTransaction().add(R.id.activity_main_container, fragment, tag)
            .addToBackStack(tag).commit()
    }
    private fun initialize() {
              showFragment(DataFragment.newInstance(), "DataFragment")
        client = setUpApolloClient()
        Log.i("sieouwoewew", "response fata ${client}")
        lifecycleScope.launchWhenResumed {
            val response = client.query(FindAlbumQuery("5")).execute()
            Log.i("sieouwoewew", "response fata ${response.data}")
            val out = client.mutation(CreateTodoMutation("Create album", false)).execute()
            Log.i("sieouwoewew", "create fata ${out.data}")
        }

    }

    fun setUpApolloClient(): ApolloClient {
//        val logging = HttpLoggingInterceptor()
//        logging.level = HttpLoggingInterceptor.Level.BODY
//        val okHttp = OkHttpClient.Builder().addInterceptor(logging)
        return ApolloClient.builder().serverUrl("https://graphqlzero.almansi.me/api")
            .build()
        //.okHttpClient(okHttp.build()).

    }
}